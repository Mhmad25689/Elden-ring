# جسر ستورمفيل — مشروع Godot 4.3 الأصلي (بدون أي HTML أو WebView)

هذا المشروع مبني 100% بمحرك **Godot 4.3 (Mobile Renderer)** ولغة **GDScript** وخامات **PBR (NoiseTexture2D Normal Maps + ACES Tone Mapping + Erdtree Glow)**، ومضبوط للعمل بالوضع الأفقي (**Landscape**) على معالج **Helio G99**.

## كيف تستخرج ملف الـ APK:
1. **عبر GitHub Actions (تلقائياً خلال دقيقتين):**
   - فك الضغط عن هذا الملف وارفع جميع محتوياته (بما فيها مجلد `.github/workflows/build-apk.yml` الموجود فعلياً داخل الأرشيف) إلى مستودع GitHub.
   - ادخل إلى تبويب **Actions** وحمّل ملف `EldenBridge-Stormveil-ARM64.apk`.
2. **أو مباشرة على هاتفك عبر تطبيق محرر Godot 4 للأندرويد:**
   - افتح تطبيق **Godot Editor 4.3** من متجر Google Play على هاتفك، واضغط **Import** واختر ملف `project.godot` لتشغيل اللعبة وتعديلها مباشرة على الهاتف!
