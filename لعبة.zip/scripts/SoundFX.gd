extends Node

var muted: bool = false
var player_pool: Array[AudioStreamPlayer] = []

func _ready() -> void:
	for i in range(6):
		var asp := AudioStreamPlayer.new()
		add_child(asp)
		player_pool.append(asp)

func play_tone(freq_start: float, freq_end: float, duration: float, volume_db: float = -8.0, noise_mix: float = 0.15) -> void:
	if muted:
		return
	var sample_rate := 22050
	var count := int(duration * sample_rate)
	var data := PackedByteArray()
	data.resize(count * 2)
	var phase := 0.0
	for i in range(count):
		var t := float(i) / float(count)
		var env := pow(1.0 - t, 1.6)
		var freq := lerpf(freq_start, freq_end, t)
		phase += freq / float(sample_rate)
		var wave := sin(phase * TAU) * (1.0 - noise_mix) + randf_range(-1.0, 1.0) * noise_mix
		var sample := int(clampf(wave * env, -1.0, 1.0) * 32760.0)
		data.encode_s16(i * 2, sample)

	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = sample_rate
	wav.data = data

	for asp in player_pool:
		if not asp.playing:
			asp.stream = wav
			asp.volume_db = volume_db
			asp.play()
			return

func slash() -> void:
	play_tone(420.0, 130.0, 0.14, -7.0, 0.35)

func heavy_slam() -> void:
	play_tone(180.0, 48.0, 0.32, -4.0, 0.45)

func hit_flesh() -> void:
	play_tone(140.0, 55.0, 0.18, -5.0, 0.5)

func parry_clang() -> void:
	play_tone(980.0, 1320.0, 0.24, -4.0, 0.08)

func grace_heal() -> void:
	play_tone(440.0, 880.0, 0.38, -6.0, 0.05)

func dodge_step() -> void:
	play_tone(220.0, 110.0, 0.11, -11.0, 0.4)
