extends CharacterBody3D

signal boss_updated
signal boss_telegraph(msg: String)
signal boss_defeated

var max_hp: float = 480.0
var hp: float = 480.0
var poise: float = 100.0
var max_poise: float = 100.0
var phase: int = 1

var state: String = "stalk" # stalk, delayed_windup, swing, leap_slam, golden_hammer, stunned, recover
var timer: float = 0.0
var cooldown: float = 1.1
var hit_dealt: bool = false
var current_attack: String = "delayed_staff"

var player_ref: Node3D = null
var sfx_ref: Node = null

@onready var visual_root: Node3D = $VisualRoot
@onready var weapon_pivot: Node3D = $VisualRoot/WeaponPivot
@onready var golden_hammer_mesh: MeshInstance3D = $VisualRoot/WeaponPivot/GoldenHammer
@onready var omen_aura_light: OmniLight3D = $VisualRoot/OmenAuraLight

func _ready() -> void:
	_try_load_custom_glb()

func _try_load_custom_glb() -> void:
	var glb_path := "res://assets/models/boss.glb"
	if ResourceLoader.exists(glb_path):
		var packed: PackedScene = load(glb_path)
		if packed:
			var inst := packed.instantiate()
			visual_root.add_child(inst)

func reset_boss(spawn_pos: Vector3) -> void:
	global_position = spawn_pos
	hp = max_hp
	poise = max_poise
	phase = 1
	state = "stalk"
	timer = 0.0
	cooldown = 1.2
	golden_hammer_mesh.visible = false
	omen_aura_light.light_color = Color(1.0, 0.65, 0.2)
	emit_signal("boss_updated")
	emit_signal("boss_telegraph", "")

func _physics_process(delta: float) -> void:
	if not is_instance_valid(player_ref) or hp <= 0.0:
		return

	var to_player := player_ref.global_position - global_position
	to_player.y = 0.0
	var dist := to_player.length()
	var target_yaw := atan2(-to_player.x, -to_player.z)

	timer += delta
	weapon_pivot.rotation = Vector3.ZERO

	match state:
		"stalk":
			visual_root.rotation.y = lerp_angle(visual_root.rotation.y, target_yaw, 6.0 * delta)
			var spd := 4.4 if phase == 2 else 3.3
			if dist > 3.3:
				var dir := to_player.normalized()
				velocity.x = dir.x * spd
				velocity.z = dir.z * spd
			else:
				velocity.x = 0.0
				velocity.z = 0.0
			cooldown -= delta
			if dist <= 4.6 and cooldown <= 0.0:
				_choose_next_attack()

		"delayed_windup":
			velocity = Vector3.ZERO
			visual_root.rotation.y = lerp_angle(visual_root.rotation.y, target_yaw, 8.0 * delta)
			weapon_pivot.rotation.x = 1.25
			weapon_pivot.rotation.y = -0.85
			# Classic Margit delayed feint windup
			var wind_dur := 0.92 if current_attack == "delayed_staff" else 0.72
			if timer >= wind_dur:
				state = "swing"
				timer = 0.0
				if sfx_ref: sfx_ref.heavy_slam()

		"swing":
			emit_signal("boss_telegraph", "")
			var p := timer / 0.34
			if current_attack == "golden_hammer":
				weapon_pivot.rotation.x = 1.25 - p * 2.85
			else:
				weapon_pivot.rotation.y = -1.2 + p * 2.5
			if p > 0.25 and p < 0.75 and not hit_dealt:
				var reach := 4.8 if current_attack == "golden_hammer" else 4.2
				if dist <= reach and player_ref.has_method("receive_boss_attack"):
					player_ref.receive_boss_attack(42.0 if current_attack == "golden_hammer" else 28.0)
					hit_dealt = true
			if timer >= 0.34:
				golden_hammer_mesh.visible = (phase == 2)
				state = "recover"
				timer = 0.0

		"stunned":
			velocity = Vector3.ZERO
			weapon_pivot.rotation.z = 0.65
			if timer >= 1.8:
				poise = max_poise
				state = "stalk"
				timer = 0.0
				emit_signal("boss_telegraph", "")

		"recover":
			velocity = Vector3.ZERO
			var rec_dur := 0.75 if phase == 2 else 1.05
			if timer >= rec_dur:
				state = "stalk"
				timer = 0.0
				cooldown = 0.55 if phase == 2 else 0.95

	move_and_slide()
	global_position.x = clampf(global_position.x, -5.8, 5.8)
	global_position.z = clampf(global_position.z, -22.0, 22.0)

func _choose_next_attack() -> void:
	timer = 0.0
	hit_dealt = false
	state = "delayed_windup"
	if phase == 2 and randf() < 0.5:
		current_attack = "golden_hammer"
		golden_hammer_mesh.visible = true
		emit_signal("boss_telegraph", "⚠️ مطرقة الشجرة الذهبية الساحقة — راوغ للجانب!")
	else:
		current_attack = "delayed_staff"
		emit_signal("boss_telegraph", "⚠️ ضربة مارغيت المتأخرة (Delayed Attack) — لا تستعجل المراوغة!")

func take_damage(dmg: float, poise_dmg: float) -> void:
	if state == "stunned":
		dmg *= 1.45 # Critical hit bonus while stance broken
	hp = maxf(0.0, hp - dmg)
	poise -= poise_dmg
	if sfx_ref: sfx_ref.hit_flesh()

	if phase == 1 and hp <= max_hp * 0.5 and hp > 0.0:
		phase = 2
		golden_hammer_mesh.visible = true
		omen_aura_light.light_color = Color(1.0, 0.85, 0.25)
		omen_aura_light.light_energy = 3.5

	if poise <= 0.0 and state != "stunned" and hp > 0.0:
		state = "stunned"
		timer = 0.0
		emit_signal("boss_telegraph", "✨ كُسر توازن الزعيم (Stance Broken) — اضرب الآن لضربة حرجة!")

	emit_signal("boss_updated")
	if hp <= 0.0:
		emit_signal("boss_telegraph", "")
		emit_signal("boss_defeated")
