extends Node3D

@onready var player = $Player
@onready var boss = $BossMargit
@onready var sfx = $SoundFX
@onready var world_env: WorldEnvironment = $WorldEnvironment

@onready var hp_bar: ProgressBar = $HUD/TopRightPanel/VBox/HPBar
@onready var stam_bar: ProgressBar = $HUD/TopRightPanel/VBox/StaminaBar
@onready var flask_label: Label = $HUD/TopRightPanel/VBox/FlaskRow/FlaskLabel
@onready var lock_label: Label = $HUD/TopRightPanel/VBox/FlaskRow/LockLabel

@onready var boss_bar: ProgressBar = $HUD/BossPanel/VBox/BossBar
@onready var boss_phase_label: Label = $HUD/BossPanel/VBox/HeaderRow/PhaseLabel
@onready var telegraph_label: Label = $HUD/TelegraphBanner
@onready var end_modal: Control = $HUD/EndModal
@onready var end_title: Label = $HUD/EndModal/Card/VBox/EndTitle
@onready var end_desc: Label = $HUD/EndModal/Card/VBox/EndDesc

@onready var joy_base: Control = $HUD/JoystickZone/JoyBase
@onready var joy_knob: Control = $HUD/JoystickZone/JoyBase/JoyKnob
var joy_touch_idx: int = -1

func _ready() -> void:
	player.boss_ref = boss
	player.sfx_ref = sfx
	boss.player_ref = player
	boss.sfx_ref = sfx

	player.connect("stats_updated", Callable(self, "_on_player_stats_updated"))
	player.connect("player_died", Callable(self, "_on_player_died"))
	boss.connect("boss_updated", Callable(self, "_on_boss_updated"))
	boss.connect("boss_telegraph", Callable(self, "_on_boss_telegraph"))
	boss.connect("boss_defeated", Callable(self, "_on_boss_defeated"))

	# Bind Touch Buttons
	$HUD/ActionButtons/BtnLight.connect("pressed", Callable(player, "action_light_attack"))
	$HUD/ActionButtons/BtnHeavy.connect("pressed", Callable(player, "action_heavy_attack"))
	$HUD/ActionButtons/BtnDodge.connect("pressed", Callable(player, "action_dodge"))
	$HUD/ActionButtons/BtnHeal.connect("pressed", Callable(player, "action_heal"))
	$HUD/ActionButtons/BtnJump.connect("pressed", Callable(player, "action_jump"))
	$HUD/ActionButtons/BtnLock.connect("pressed", Callable(self, "_toggle_lock_on"))
	$HUD/ActionButtons/BtnBlock.connect("button_down", Callable(self, "_on_block_down"))
	$HUD/ActionButtons/BtnBlock.connect("button_up", Callable(self, "_on_block_up"))

	$HUD/TopLeftButtons/BtnLow.connect("pressed", Callable(self, "_set_quality").bind("low"))
	$HUD/TopLeftButtons/BtnMed.connect("pressed", Callable(self, "_set_quality").bind("medium"))
	$HUD/TopLeftButtons/BtnHigh.connect("pressed", Callable(self, "_set_quality").bind("high"))
	$HUD/EndModal/Card/VBox/BtnRespawn.connect("pressed", Callable(self, "_respawn_at_grace"))

	_set_quality("medium")
	_respawn_at_grace()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var local_pos := joy_base.get_global_rect()
		if event.pressed and joy_touch_idx == -1 and local_pos.has_point(event.position):
			joy_touch_idx = event.index
			_update_joystick(event.position)
		elif not event.pressed and event.index == joy_touch_idx:
			joy_touch_idx = -1
			player.joy_vec = Vector2.ZERO
			joy_knob.position = joy_base.size * 0.5 - joy_knob.size * 0.5
	elif event is InputEventScreenDrag and event.index == joy_touch_idx:
		_update_joystick(event.position)

func _update_joystick(screen_pos: Vector2) -> void:
	var center := joy_base.global_position + joy_base.size * 0.5
	var delta_v := screen_pos - center
	var max_r := 46.0
	if delta_v.length() > max_r:
		delta_v = delta_v.normalized() * max_r
	joy_knob.position = (joy_base.size * 0.5 - joy_knob.size * 0.5) + delta_v
	player.joy_vec = delta_v / max_r

func _toggle_lock_on() -> void:
	player.locked_on = not player.locked_on
	_on_player_stats_updated()

func _on_block_down() -> void:
	player.set_blocking(true)

func _on_block_up() -> void:
	player.set_blocking(false)

func _set_quality(level: String) -> void:
	var vp := get_viewport()
	var env := world_env.environment
	match level:
		"low":
			vp.scaling_3d_scale = 0.65
			env.glow_enabled = false
		"medium":
			vp.scaling_3d_scale = 0.85
			env.glow_enabled = true
			env.glow_intensity = 0.65
		"high":
			vp.scaling_3d_scale = 1.0
			env.glow_enabled = true
			env.glow_intensity = 1.05

func _on_player_stats_updated() -> void:
	hp_bar.max_value = player.max_hp
	hp_bar.value = player.hp
	stam_bar.max_value = player.max_stamina
	stam_bar.value = player.stamina
	flask_label.text = "🧪 دموع القرمزي: %d" % player.flasks
	lock_label.text = "🎯 القفل: مفعّل" if player.locked_on else "🎯 القفل: حر"

func _on_boss_updated() -> void:
	boss_bar.max_value = boss.max_hp
	boss_bar.value = boss.hp
	boss_phase_label.text = "المرحلة الثانية (مطرقة النور)" if boss.phase == 2 else "المرحلة الأولى"

func _on_boss_telegraph(msg: String) -> void:
	telegraph_label.text = msg
	telegraph_label.visible = (msg != "")

func _on_player_died() -> void:
	end_title.text = "لقد سقطت (YOU DIED)"
	end_desc.text = "ستعود عند موقع النعمة (Site of Grace) بجرعاتك الكاملة دون خسارة تقدمك."
	end_modal.visible = true

func _on_boss_defeated() -> void:
	end_title.text = "قُضي على العدو العظيم (GREAT ENEMY FELLED)"
	end_desc.text = "انتصرت على مارغيت حارس جسر ستورمفيل تحت وهج الشجرة الذهبية!"
	end_modal.visible = true

func _respawn_at_grace() -> void:
	end_modal.visible = false
	player.reset_at_grace(Vector3(0.0, 0.2, 11.0))
	boss.reset_boss(Vector3(0.0, 0.2, -9.0))
