extends CharacterBody3D

signal stats_updated
signal player_died

@export var move_speed: float = 6.2
@export var dodge_speed: float = 13.5

var max_hp: float = 100.0
var hp: float = 100.0
var rally_hp: float = 100.0
var max_stamina: float = 100.0
var stamina: float = 100.0
var flasks: int = 4

var locked_on: bool = true
var state: String = "idle" # idle, light1, light2, heavy, dodge, block, heal, stagger
var state_timer: float = 0.0
var invuln_timer: float = 0.0
var combo_queued: bool = false
var hit_registered: bool = false
var dodge_dir: Vector3 = Vector3.FORWARD

var joy_vec: Vector2 = Vector2.ZERO
var boss_ref: Node3D = null
var sfx_ref: Node = null

@onready var visual_root: Node3D = $VisualRoot
@onready var sword_pivot: Node3D = $VisualRoot/SwordPivot
@onready var shield_mesh: Node3D = $VisualRoot/ShieldMesh
@onready var cam_rig: Node3D = $CameraRig
@onready var cam_3d: Camera3D = $CameraRig/Camera3D

func _ready() -> void:
	_try_load_custom_glb()

func _try_load_custom_glb() -> void:
	var glb_path := "res://assets/models/player.glb"
	if ResourceLoader.exists(glb_path):
		var packed: PackedScene = load(glb_path)
		if packed:
			var inst := packed.instantiate()
			visual_root.add_child(inst)

func reset_at_grace(spawn_pos: Vector3) -> void:
	global_position = spawn_pos
	velocity = Vector3.ZERO
	hp = max_hp
	rally_hp = max_hp
	stamina = max_stamina
	flasks = 4
	state = "idle"
	state_timer = 0.0
	invuln_timer = 0.0
	combo_queued = false
	emit_signal("stats_updated")

func _physics_process(delta: float) -> void:
	if invuln_timer > 0.0:
		invuln_timer -= delta
	if rally_hp > hp:
		rally_hp = maxf(hp, rally_hp - 6.5 * delta)

	if not is_on_floor():
		velocity.y -= 20.0 * delta
	else:
		if velocity.y < 0.0:
			velocity.y = -0.1

	# Stamina regeneration
	if state == "idle":
		stamina = minf(max_stamina, stamina + 26.0 * delta)
	elif state == "block":
		stamina = minf(max_stamina, stamina + 8.0 * delta)

	var input_dir := _get_move_vector()
	var dist_to_boss := 999.0
	var to_boss := Vector3.FORWARD
	if is_instance_valid(boss_ref):
		to_boss = boss_ref.global_position - global_position
		to_boss.y = 0.0
		dist_to_boss = to_boss.length()

	state_timer += delta
	sword_pivot.rotation = Vector3.ZERO
	shield_mesh.position = Vector3(-0.46, 1.25, -0.22)

	match state:
		"idle", "block":
			var spd := 3.1 if state == "block" else move_speed
			if state == "block":
				shield_mesh.position = Vector3(-0.18, 1.32, -0.48)
			velocity.x = input_dir.x * spd
			velocity.z = input_dir.z * spd
			if locked_on and dist_to_boss > 0.2:
				var target_yaw := atan2(-to_boss.x, -to_boss.z)
				visual_root.rotation.y = lerp_angle(visual_root.rotation.y, target_yaw, 12.0 * delta)
			elif input_dir.length_squared() > 0.02:
				var move_yaw := atan2(-input_dir.x, -input_dir.z)
				visual_root.rotation.y = lerp_angle(visual_root.rotation.y, move_yaw, 10.0 * delta)

		"light1", "light2":
			velocity.x = move_toward(velocity.x, 0.0, 18.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 18.0 * delta)
			var p := state_timer / 0.35
			var dir_sign := 1.0 if state == "light1" else -1.0
			sword_pivot.rotation.y = dir_sign * (-1.2 + p * 2.4)
			sword_pivot.rotation.x = -0.32
			if p > 0.32 and p < 0.72 and not hit_registered and dist_to_boss <= 3.5:
				_deal_hit_to_boss(28.0, 18.0)
				hit_registered = true
			if state_timer >= 0.35:
				if state == "light1" and combo_queued and stamina >= 15.0:
					stamina -= 15.0
					state = "light2"
					state_timer = 0.0
					hit_registered = false
					combo_queued = false
					if sfx_ref: sfx_ref.slash()
				else:
					state = "idle"
					state_timer = 0.0

		"heavy":
			velocity.x = move_toward(velocity.x, 0.0, 16.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 16.0 * delta)
			var p := state_timer / 0.62
			sword_pivot.rotation.x = 0.95 if p < 0.45 else -1.55
			if p > 0.46 and p < 0.78 and not hit_registered and dist_to_boss <= 3.9:
				_deal_hit_to_boss(56.0, 45.0)
				hit_registered = true
			if state_timer >= 0.62:
				state = "idle"
				state_timer = 0.0

		"dodge":
			velocity.x = dodge_dir.x * dodge_speed
			velocity.z = dodge_dir.z * dodge_speed
			visual_root.rotation.x = (state_timer / 0.38) * TAU
			if state_timer >= 0.38:
				visual_root.rotation.x = 0.0
				state = "idle"
				state_timer = 0.0

		"heal":
			velocity.x = 0.0
			velocity.z = 0.0
			if state_timer >= 0.45:
				state = "idle"
				state_timer = 0.0

		"stagger":
			velocity.x = move_toward(velocity.x, 0.0, 15.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 15.0 * delta)
			if state_timer >= 0.32:
				state = "idle"
				state_timer = 0.0

	move_and_slide()
	# Keep player inside Stormveil Bridge bounds
	global_position.x = clampf(global_position.x, -6.2, 6.2)
	global_position.z = clampf(global_position.z, -24.0, 24.0)

	_update_camera(delta)
	emit_signal("stats_updated")

func _deal_hit_to_boss(dmg: float, poise_dmg: float) -> void:
	if is_instance_valid(boss_ref) and boss_ref.has_method("take_damage"):
		boss_ref.take_damage(dmg, poise_dmg)
		# Bloodborne Rally mechanic: recover lost rally_hp on aggressive counter-hits
		if hp < rally_hp:
			hp = minf(rally_hp, hp + 10.0)

func _get_move_vector() -> Vector3:
	var v := joy_vec
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): v.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): v.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): v.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): v.y += 1.0
	if v.length() > 1.0:
		v = v.normalized()
	var cam_basis := cam_3d.global_transform.basis
	var forward := -cam_basis.z
	forward.y = 0.0
	forward = forward.normalized()
	var right := cam_basis.x
	right.y = 0.0
	right = right.normalized()
	return (right * v.x + forward * (-v.y)).normalized() * v.length()

func _update_camera(delta: float) -> void:
	if locked_on and is_instance_valid(boss_ref):
		var dir := (boss_ref.global_position - global_position)
		dir.y = 0.0
		if dir.length_squared() < 0.01:
			dir = Vector3.FORWARD
		dir = dir.normalized()
		var desired_pos := global_position - dir * 5.8 + Vector3(0.0, 3.1, 0.0)
		cam_rig.global_position = cam_rig.global_position.lerp(desired_pos, 10.0 * delta)
		var look_target := boss_ref.global_position.lerp(global_position, 0.35) + Vector3(0.0, 1.7, 0.0)
		cam_3d.look_at(look_target, Vector3.UP)
	else:
		var back := Vector3(sin(visual_root.rotation.y), 0.0, cos(visual_root.rotation.y))
		var desired_pos := global_position + back * 6.0 + Vector3(0.0, 3.3, 0.0)
		cam_rig.global_position = cam_rig.global_position.lerp(desired_pos, 8.0 * delta)
		cam_3d.look_at(global_position + Vector3(0.0, 1.6, 0.0), Vector3.UP)

func action_light_attack() -> void:
	if state == "light1" and state_timer > 0.12:
		combo_queued = true
		return
	if (state == "idle" or state == "block") and stamina >= 15.0:
		stamina -= 15.0
		state = "light1"
		state_timer = 0.0
		hit_registered = false
		combo_queued = false
		if sfx_ref: sfx_ref.slash()

func action_heavy_attack() -> void:
	if (state == "idle" or state == "block") and stamina >= 30.0:
		stamina -= 30.0
		state = "heavy"
		state_timer = 0.0
		hit_registered = false
		if sfx_ref: sfx_ref.heavy_slam()

func action_dodge() -> void:
	if (state == "idle" or state == "block") and stamina >= 20.0:
		stamina -= 20.0
		state = "dodge"
		state_timer = 0.0
		invuln_timer = 0.36
		var mv := _get_move_vector()
		if mv.length_squared() > 0.01:
			dodge_dir = mv.normalized()
		else:
			dodge_dir = -visual_root.global_transform.basis.z.normalized()
		if sfx_ref: sfx_ref.dodge_step()

func action_heal() -> void:
	if state == "idle" and flasks > 0 and hp < max_hp:
		flasks -= 1
		state = "heal"
		state_timer = 0.0
		hp = minf(max_hp, hp + 50.0)
		rally_hp = hp
		if sfx_ref: sfx_ref.grace_heal()
		emit_signal("stats_updated")

func action_jump() -> void:
	if is_on_floor() and (state == "idle" or state == "block") and stamina >= 12.0:
		stamina -= 12.0
		velocity.y = 7.6

func set_blocking(active: bool) -> void:
	if active and state == "idle":
		state = "block"
	elif not active and state == "block":
		state = "idle"

func receive_boss_attack(dmg: float) -> void:
	if invuln_timer > 0.0:
		return
	if state == "block" and stamina >= 18.0:
		stamina -= 18.0
		hp = maxf(0.0, hp - dmg * 0.18)
		if sfx_ref: sfx_ref.parry_clang()
	else:
		rally_hp = hp
		hp = maxf(0.0, hp - dmg)
		state = "stagger"
		state_timer = 0.0
		if sfx_ref: sfx_ref.hit_flesh()
	emit_signal("stats_updated")
	if hp <= 0.0:
		emit_signal("player_died")
