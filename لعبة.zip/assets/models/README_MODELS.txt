ضع مجسماتك ثلاثية الأبعاد الجاهزة هنا (اختياري):
- res://assets/models/player.glb
- res://assets/models/boss.glb
وسيقوم كل من PlayerController.gd و BossMargit.gd بتحميلها تلقائياً داخل المشهد!
